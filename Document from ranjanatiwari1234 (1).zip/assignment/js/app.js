function validateTextbox() {
 debugger;
 
var box = document.getElementById("name");
var email = document.getElementById("email"); 
var  age_chcek= document.getElementById("age_chcek");
 var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
 var checkdata=0;
 if (box.value == "") {
alert("The name field cannot be blank");
checkdata=1;
 }
 else if (email.value == "") {
alert("The email field cannot be blank");
checkdata=1;
 }
else if(email.value.match(mailformat))
{
}
else
{
alert("You have entered an invalid email address!");
checkdata=1;
}
 if (age_chcek.value == "" && checkdata==0) {
alert("The age field cannot be blank");
 }
 else{
	 //alert("I am here but not hoingkmi");
	 location.href = "message.html";
	 debugger;
	 //window.open('message.html');
 }
 


 
 }
 
 function ValidateEmail(mail) 
{
 
}